
# GTA5 Car Mod Editor — Android V1

Offline Android project for the planned GTA V car-mod editor.

## V1 flow
1. Open the app.
2. Tap `GO CAR MODIFICATION`.
3. Select a `.yft` vehicle model.
4. Select a `.ytd` texture dictionary.
5. Open the editor.

## Next modules
- GTA V YFT parser/renderer
- YTD texture dictionary reader
- DDS/texture preview
- 3D vehicle viewer
- Decal/text editor
- Export of modified YTD/YFT package

The current project is a UI/prototype shell; it does not yet parse GTA V binary formats.
