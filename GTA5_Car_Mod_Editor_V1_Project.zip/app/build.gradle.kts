plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gta5.carmodeditor"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gta5.carmodeditor"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}