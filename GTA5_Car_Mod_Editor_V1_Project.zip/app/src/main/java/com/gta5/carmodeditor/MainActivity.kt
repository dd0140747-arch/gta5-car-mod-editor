package com.gta5.carmodeditor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val yftCode = 1001
    private val ytdCode = 1002
    private var yft: Uri? = null
    private var ytd: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.goModification).setOnClickListener {
            showPicker()
        }
    }

    private fun showPicker() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(16,16,16))
        }

        fun label(text: String) = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 17f
            setPadding(0, 20, 0, 10)
        }

        val title = TextView(this).apply {
            text = "ADD GTA V CAR FILES"
            setTextColor(Color.rgb(255,109,0))
            textSize = 26f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 30)
        }

        val yftStatus = label("YFT: Not selected")
        val ytdStatus = label("YTD: Not selected")
        val yftButton = Button(this).apply { text = "SELECT .YFT (3D MODEL)" }
        val ytdButton = Button(this).apply { text = "SELECT .YTD (TEXTURES)" }
        val continueButton = Button(this).apply { text = "OPEN CAR EDITOR"; isEnabled = false }

        yftButton.setOnClickListener { pick(yftCode) }
        ytdButton.setOnClickListener { pick(ytdCode) }

        root.addView(title)
        root.addView(yftStatus)
        root.addView(yftButton)
        root.addView(ytdStatus)
        root.addView(ytdButton)
        root.addView(continueButton)

        setContentView(root)

        root.tag = Pair(yftStatus, ytdStatus)
        root.setOnHierarchyChangeListener(object : LinearLayout.OnHierarchyChangeListener {
            override fun onChildViewAdded(parent: android.view.View?, child: android.view.View?) {}
            override fun onChildViewRemoved(parent: android.view.View?, child: android.view.View?) {}
        })

        yftButton.setOnClickListener { pick(yftCode) }
        ytdButton.setOnClickListener { pick(ytdCode) }
        continueButton.setOnClickListener { showEditor() }
    }

    private fun pick(code: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, code)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == yftCode) yft = uri
        if (requestCode == ytdCode) ytd = uri

        // Refresh picker UI with selected filenames.
        showPicker()
        Toast.makeText(this, "File selected: ${uri.lastPathSegment}", Toast.LENGTH_SHORT).show()
    }

    private fun showEditor() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.rgb(16,16,16))
        }
        val title = TextView(this).apply {
            text = "CAR MODIFICATION"
            textSize = 25f
            setTextColor(Color.rgb(255,109,0))
            gravity = Gravity.CENTER
        }
        val preview = TextView(this).apply {
            text = "3D CAR PREVIEW\n\nYFT + YTD loaded\n\n3D renderer will be connected in the next build."
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(10, 100, 10, 100)
        }
        val addText = Button(this).apply { text = "✍ ADD TEXT / DECAL" }
        val textures = Button(this).apply { text = "🎨 TEXTURES & COLORS" }
        val export = Button(this).apply { text = "💾 EXPORT MOD" }

        addText.setOnClickListener {
            Toast.makeText(this, "Decal editor is the next module.", Toast.LENGTH_SHORT).show()
        }
        textures.setOnClickListener {
            Toast.makeText(this, "YTD texture browser is the next module.", Toast.LENGTH_SHORT).show()
        }
        export.setOnClickListener {
            Toast.makeText(this, "Export pipeline will be added after YFT/YTD parsing.", Toast.LENGTH_LONG).show()
        }

        root.addView(title)
        root.addView(preview)
        root.addView(addText)
        root.addView(textures)
        root.addView(export)
        setContentView(root)
    }
}